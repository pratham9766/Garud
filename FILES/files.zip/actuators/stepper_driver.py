"""
actuators/stepper_driver.py
------------------------------
ULN2003 unipolar stepper driver wrapper (e.g. for a 28BYJ-48), driven
straight off 4 RPi GPIOs through the Darlington array on the
CON_ULN2003 connector (J3): IN1=GPIO25, IN2=GPIO24, IN3=GPIO23,
IN4=GPIO18.

Uses Adafruit CircuitPython Motor's StepperMotor class in
"microsteps=None" mode, which is the correct mode for plain digital
GPIO coil drive (no PWM channel needed, unlike a DRV8833/TB6612 setup).

Requires: adafruit-circuitpython-motor
"""
import time
import digitalio
from adafruit_motor import stepper

import config


class ULN2003Stepper:
    def __init__(self,
                 in1_pin=config.ULN2003_IN1_PIN,
                 in2_pin=config.ULN2003_IN2_PIN,
                 in3_pin=config.ULN2003_IN3_PIN,
                 in4_pin=config.ULN2003_IN4_PIN,
                 step_delay=config.STEPPER_STEP_DELAY):
        self._pins = []
        for pin in (in1_pin, in2_pin, in3_pin, in4_pin):
            d = digitalio.DigitalInOut(pin)
            d.direction = digitalio.Direction.OUTPUT
            self._pins.append(d)

        # microsteps=None => plain single/double-coil unipolar stepping,
        # required since ULN2003 outputs are on/off, not PWM.
        self.motor = stepper.StepperMotor(
            self._pins[0], self._pins[1], self._pins[2], self._pins[3],
            microsteps=None,
        )
        self.step_delay = step_delay

    def step(self, steps, style=stepper.SINGLE):
        """Move `steps` steps. Positive = FORWARD, negative = BACKWARD."""
        direction = stepper.FORWARD if steps >= 0 else stepper.BACKWARD
        for _ in range(abs(steps)):
            self.motor.onestep(direction=direction, style=style)
            time.sleep(self.step_delay)

    def release(self):
        """De-energize all coils - prevents overheating / saves power when idle."""
        self.motor.release()
